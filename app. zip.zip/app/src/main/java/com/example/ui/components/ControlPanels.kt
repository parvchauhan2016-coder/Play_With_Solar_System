package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AtmosphereComposition
import com.example.model.PlanetData
import com.example.model.StarData
import com.example.model.StarType
import com.example.model.SurfaceComposition
import com.example.ui.AttackType
import kotlin.math.roundToInt

@Composable
fun ParameterInspectorPanel(
    planet: PlanetData,
    star: StarData,
    showMagneticField: Boolean,
    colonyStatusText: String,
    eventLogs: List<String>,
    onGeneratePlanet: () -> Unit,
    onLaunchAttack: (AttackType) -> Unit,
    onToggleShield: () -> Unit,
    onDeployHumans: (Long) -> Unit,
    onRepairPlanet: () -> Unit,
    onUpdatePlanet: (PlanetData) -> Unit,
    onUpdateStar: (StarData) -> Unit,
    onToggleMagneticField: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Game Sandbox", "Surface Area", "Physical", "Atmosphere", "Host Star")
    val tabIcons = listOf(Icons.Default.RocketLaunch, Icons.Default.Landscape, Icons.Default.Public, Icons.Default.Air, Icons.Default.WbSunny)

    Column(
        modifier = modifier
            .background(Color(0xFF0F172A).copy(alpha = 0.92f), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        // Hero Generate Planet Button
        Button(
            onClick = onGeneratePlanet,
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color(0xFF0EA5E9), Color(0xFF6366F1), Color(0xFF8B5CF6))
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = "Generate", tint = Color.White)
                    Text(
                        "✨ GENERATE PLANET",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tab Header
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = Color(0xFF38BDF8),
            edgePadding = 4.dp,
            divider = {}
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(tabIcons[index], contentDescription = title, modifier = Modifier.size(16.dp)) },
                    selectedContentColor = Color(0xFF38BDF8),
                    unselectedContentColor = Color(0xFF94A3B8)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            when (selectedTab) {
                0 -> GameDockEditor(
                    planet = planet,
                    colonyStatusText = colonyStatusText,
                    eventLogs = eventLogs,
                    onLaunchAttack = onLaunchAttack,
                    onToggleShield = onToggleShield,
                    onDeployHumans = onDeployHumans,
                    onRepairPlanet = onRepairPlanet
                )
                1 -> SurfaceEditor(planet, onUpdatePlanet)
                2 -> PhysicalPropertiesEditor(planet, showMagneticField, onUpdatePlanet, onToggleMagneticField)
                3 -> AtmosphereEditor(planet, onUpdatePlanet)
                4 -> StarSystemEditor(star, onUpdateStar)
            }
        }
    }
}

@Composable
private fun GameDockEditor(
    planet: PlanetData,
    colonyStatusText: String,
    eventLogs: List<String>,
    onLaunchAttack: (AttackType) -> Unit,
    onToggleShield: () -> Unit,
    onDeployHumans: (Long) -> Unit,
    onRepairPlanet: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Planetary Defense & Interactivity", style = MaterialTheme.typography.titleMedium, color = Color(0xFF38BDF8))

        // Shield & Integrity Status Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🛡️ Force Field Shield", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Switch(
                        checked = planet.shieldActive,
                        onCheckedChange = { onToggleShield() },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E5FF))
                    )
                }
                LinearProgressIndicator(
                    progress = { planet.shieldPowerPct / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFF00E5FF),
                    trackColor = Color(0xFF334155)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("❤️ Planet Structural Health", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Text("${planet.healthPct.toInt()}%", color = if (planet.healthPct > 50) Color(0xFF22C55E) else Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { planet.healthPct / 100f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = if (planet.healthPct > 50) Color(0xFF22C55E) else Color(0xFFEF4444),
                    trackColor = Color(0xFF334155)
                )
            }
        }

        // Weapon Arsenal
        Text("🚀 Planetary Arsenal & Disasters", style = MaterialTheme.typography.titleSmall, color = Color.White)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onLaunchAttack(AttackType.MISSILE) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("🚀 Missile Strike", fontSize = 11.sp, color = Color.White)
            }

            Button(
                onClick = { onLaunchAttack(AttackType.ASTEROID) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C)),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("☄️ Asteroid", fontSize = 11.sp, color = Color.White)
            }
        }

        // Human Colony Controls
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2942)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("👨‍🚀 Human Colony Simulator", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(colonyStatusText, color = Color.White, fontSize = 12.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onDeployHumans(10_000_000L) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("+10M Colonists", fontSize = 10.sp)
                    }

                    OutlinedButton(
                        onClick = { onDeployHumans(500_000_000L) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) {
                        Text("+500M Colonists", fontSize = 10.sp)
                    }
                }
            }
        }

        // Repair World Button
        OutlinedButton(
            onClick = onRepairPlanet,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF34D399))
        ) {
            Icon(Icons.Default.Build, contentDescription = "Repair", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("🔧 Repair World & Restore Health", fontSize = 12.sp)
        }

        // Live Event Log Feed
        Text("📜 World Sandbox Event Log", style = MaterialTheme.typography.titleSmall, color = Color.White)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
            modifier = Modifier.fillMaxWidth().height(120.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (eventLogs.isEmpty()) {
                    Text("No sandbox events recorded yet.", fontSize = 11.sp, color = Color(0xFF64748B))
                } else {
                    eventLogs.reversed().forEach { log ->
                        Text(log, fontSize = 10.sp, color = Color(0xFFCBD5E1))
                    }
                }
            }
        }
    }
}

@Composable
private fun PhysicalPropertiesEditor(
    planet: PlanetData,
    showMagneticField: Boolean,
    onUpdatePlanet: (PlanetData) -> Unit,
    onToggleMagneticField: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Physical & Orbital Parameters", style = MaterialTheme.typography.titleMedium, color = Color(0xFF38BDF8))

        // Mass
        SliderParameter(
            label = "Mass",
            valueText = "%.2f M⊕".format(planet.massEarth),
            value = planet.massEarth.toFloat(),
            range = 0.01f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(massEarth = it.toDouble())) }
        )

        // Radius
        SliderParameter(
            label = "Radius",
            valueText = "%.2f R⊕".format(planet.radiusEarth),
            value = planet.radiusEarth.toFloat(),
            range = 0.1f..15f,
            onValueChange = { onUpdatePlanet(planet.copy(radiusEarth = it.toDouble())) }
        )

        // Gravity info box
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Surface Gravity", color = Color(0xFF94A3B8), fontSize = 13.sp)
                Text(
                    "%.2f g (%.1f m/s²)".format(planet.surfaceGravityEarth, planet.surfaceGravityMs2),
                    color = Color(0xFF34D399),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        // Distance from Star
        SliderParameter(
            label = "Distance from Star",
            valueText = "%.2f AU".format(planet.distanceFromStarAu),
            value = planet.distanceFromStarAu.toFloat(),
            range = 0.1f..35f,
            onValueChange = { onUpdatePlanet(planet.copy(distanceFromStarAu = it.toDouble())) }
        )

        // Rotation Speed / Day Length
        SliderParameter(
            label = "Day Length (Rotation)",
            valueText = "%.1f Hours".format(planet.rotationPeriodHours),
            value = planet.rotationPeriodHours.toFloat(),
            range = 1f..500f,
            onValueChange = { onUpdatePlanet(planet.copy(rotationPeriodHours = it.toDouble())) }
        )

        // Axial Tilt
        SliderParameter(
            label = "Axial Tilt",
            valueText = "%.1f°".format(planet.axialTiltDegrees),
            value = planet.axialTiltDegrees,
            range = 0f..180f,
            onValueChange = { onUpdatePlanet(planet.copy(axialTiltDegrees = it)) }
        )

        // Atmospheric Pressure
        SliderParameter(
            label = "Atmospheric Pressure",
            valueText = "%.2f atm".format(planet.atmosphericPressureAtm),
            value = planet.atmosphericPressureAtm.toFloat(),
            range = 0f..50f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphericPressureAtm = it.toDouble())) }
        )

        // Magnetic Field Strength
        SliderParameter(
            label = "Magnetic Field",
            valueText = "%.2f Gauss".format(planet.magneticFieldStrengthGauss),
            value = planet.magneticFieldStrengthGauss.toFloat(),
            range = 0f..5f,
            onValueChange = { onUpdatePlanet(planet.copy(magneticFieldStrengthGauss = it.toDouble())) }
        )

        // Moons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Number of Moons: ${planet.moonCount}", color = Color.White, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = { if (planet.moonCount > 0) onUpdatePlanet(planet.copy(moonCount = planet.moonCount - 1)) },
                    modifier = Modifier.size(32.dp).background(Color(0xFF334155), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Decrease Moons", tint = Color.White)
                }
                IconButton(
                    onClick = { if (planet.moonCount < 50) onUpdatePlanet(planet.copy(moonCount = planet.moonCount + 1)) },
                    modifier = Modifier.size(32.dp).background(Color(0xFF334155), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Increase Moons", tint = Color.White)
                }
            }
        }

        // Planetary Rings Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Planetary Rings System", color = Color.White, fontSize = 13.sp)
            Switch(
                checked = planet.hasRings,
                onCheckedChange = { onUpdatePlanet(planet.copy(hasRings = it)) },
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF38BDF8))
            )
        }

        // Magnetic Field Visual Overlay Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Show Magnetosphere Lines", color = Color(0xFF94A3B8), fontSize = 13.sp)
            Switch(
                checked = showMagneticField,
                onCheckedChange = onToggleMagneticField,
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E5FF))
            )
        }
    }
}

@Composable
private fun AtmosphereEditor(
    planet: PlanetData,
    onUpdatePlanet: (PlanetData) -> Unit
) {
    val atm = planet.atmosphere

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Atmosphere Composition Editor", style = MaterialTheme.typography.titleMedium, color = Color(0xFF38BDF8))
        Text("Adjust atmospheric gas breakdown percentages.", fontSize = 12.sp, color = Color(0xFF94A3B8))

        SliderParameter(
            label = "Nitrogen (N₂)",
            valueText = "%.1f%%".format(atm.nitrogenPct),
            value = atm.nitrogenPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphere = atm.copy(nitrogenPct = it).normalized())) }
        )

        SliderParameter(
            label = "Oxygen (O₂)",
            valueText = "%.1f%%".format(atm.oxygenPct),
            value = atm.oxygenPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphere = atm.copy(oxygenPct = it).normalized())) }
        )

        SliderParameter(
            label = "Carbon Dioxide (CO₂)",
            valueText = "%.1f%%".format(atm.carbonDioxidePct),
            value = atm.carbonDioxidePct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphere = atm.copy(carbonDioxidePct = it).normalized())) }
        )

        SliderParameter(
            label = "Methane (CH₄)",
            valueText = "%.2f%%".format(atm.methanePct),
            value = atm.methanePct,
            range = 0f..50f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphere = atm.copy(methanePct = it).normalized())) }
        )

        SliderParameter(
            label = "Argon & Other Gases",
            valueText = "%.1f%%".format(atm.argonOtherPct),
            value = atm.argonOtherPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(atmosphere = atm.copy(argonOtherPct = it).normalized())) }
        )

        // Cloud & Ice Cover
        Text("Cloud & Water Vapor", style = MaterialTheme.typography.titleSmall, color = Color.White)
        SliderParameter(
            label = "Cloud Coverage",
            valueText = "${planet.cloudPct.roundToInt()}%",
            value = planet.cloudPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(cloudPct = it)) }
        )
    }
}

@Composable
private fun SurfaceEditor(
    planet: PlanetData,
    onUpdatePlanet: (PlanetData) -> Unit
) {
    val surf = planet.surface

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Surface & Geography Editor", style = MaterialTheme.typography.titleMedium, color = Color(0xFF38BDF8))

        SliderParameter(
            label = "Ocean / Liquid Water",
            valueText = "${surf.oceanPct.roundToInt()}%",
            value = surf.oceanPct,
            range = 0f..100f,
            onValueChange = {
                val newOcean = it
                val newLand = (100f - newOcean).coerceAtLeast(0f)
                onUpdatePlanet(planet.copy(surface = surf.copy(oceanPct = newOcean, landPct = newLand), waterPct = newOcean))
            }
        )

        SliderParameter(
            label = "Ice Coverage",
            valueText = "${surf.icePct.roundToInt()}%",
            value = surf.icePct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(surface = surf.copy(icePct = it), icePct = it)) }
        )

        SliderParameter(
            label = "Desert Ratio",
            valueText = "${surf.desertPct.roundToInt()}%",
            value = surf.desertPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(surface = surf.copy(desertPct = it))) }
        )

        SliderParameter(
            label = "Forest & Vegetation",
            valueText = "${surf.forestPct.roundToInt()}%",
            value = surf.forestPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(surface = surf.copy(forestPct = it))) }
        )

        SliderParameter(
            label = "Mountains & Terrains",
            valueText = "${surf.mountainPct.roundToInt()}%",
            value = surf.mountainPct,
            range = 0f..100f,
            onValueChange = { onUpdatePlanet(planet.copy(surface = surf.copy(mountainPct = it))) }
        )
    }
}

@Composable
private fun StarSystemEditor(
    star: StarData,
    onUpdateStar: (StarData) -> Unit
) {
    var expandedDropdown by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Host Star Controls", style = MaterialTheme.typography.titleMedium, color = Color(0xFF38BDF8))

        // Star Type Dropdown
        Text("Spectral Type", color = Color(0xFF94A3B8), fontSize = 12.sp)
        Box {
            OutlinedButton(
                onClick = { expandedDropdown = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${star.type.displayName} (${star.name})", color = Color.White)
                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Star")
                }
            }

            DropdownMenu(
                expanded = expandedDropdown,
                onDismissRequest = { expandedDropdown = false }
            ) {
                StarType.entries.forEach { st ->
                    DropdownMenuItem(
                        text = { Text(st.displayName) },
                        onClick = {
                            expandedDropdown = false
                            onUpdateStar(
                                star.copy(
                                    type = st,
                                    massSolar = st.defaultMassSolar,
                                    tempKelvin = st.defaultTempKelvin,
                                    luminositySolar = st.defaultLuminositySolar,
                                    radiusSolar = st.defaultRadiusSolar
                                )
                            )
                        }
                    )
                }
            }
        }

        // Star Mass
        SliderParameter(
            label = "Star Mass",
            valueText = "%.2f M☉".format(star.massSolar),
            value = star.massSolar.toFloat(),
            range = 0.08f..30f,
            onValueChange = { onUpdateStar(star.copy(massSolar = it.toDouble())) }
        )

        // Star Luminosity
        SliderParameter(
            label = "Luminosity",
            valueText = "%.3f L☉".format(star.luminositySolar),
            value = star.luminositySolar.toFloat(),
            range = 0.001f..1000f,
            onValueChange = { onUpdateStar(star.copy(luminositySolar = it.toDouble())) }
        )

        // Star Temperature
        SliderParameter(
            label = "Star Temperature",
            valueText = "%d K".format(star.tempKelvin.roundToInt()),
            value = star.tempKelvin.toFloat(),
            range = 2000f..40000f,
            onValueChange = { onUpdateStar(star.copy(tempKelvin = it.toDouble())) }
        )
    }
}

@Composable
fun SliderParameter(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Color(0xFFCBD5E1), fontSize = 12.sp)
            Text(valueText, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF38BDF8),
                activeTrackColor = Color(0xFF0284C7),
                inactiveTrackColor = Color(0xFF334155)
            )
        )
    }
}
