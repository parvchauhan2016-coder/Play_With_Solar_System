package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlanetData
import com.example.model.StarData
import com.example.ui.AttackType
import kotlin.math.*

@Composable
fun PlanetCanvas(
    planet: PlanetData,
    star: StarData,
    simulationSpeed: Float,
    isPlaying: Boolean,
    simulatedDaysElapsed: Double,
    showMagneticField: Boolean,
    activeAttack: AttackType? = null,
    modifier: Modifier = Modifier
) {
    // User touch tilt offsets
    var userDragX by remember { mutableFloatStateOf(0f) }
    var userDragY by remember { mutableFloatStateOf(0f) }

    // Shield Pulse Animation
    val infiniteTransition = rememberInfiniteTransition(label = "ShieldPulse")
    val shieldPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ShieldAlpha"
    )

    // Attack projectile progress animation (0f to 1f)
    val attackProgress by animateFloatAsState(
        targetValue = if (activeAttack != null) 1f else 0f,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "AttackAnim"
    )

    // Pre-generate stable random star field locations
    val starsList = remember {
        List(80) {
            Triple(
                (0..1000).random() / 1000f,
                (0..1000).random() / 1000f,
                (1..3).random().toFloat()
            )
        }
    }

    val rotationAngle = (simulatedDaysElapsed * 360.0 / (planet.rotationPeriodHours / 24.0)).toFloat() % 360f

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        userDragX = (userDragX + dragAmount.x * 0.3f).coerceIn(-180f, 180f)
                        userDragY = (userDragY + dragAmount.y * 0.3f).coerceIn(-60f, 60f)
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            val center = Offset(width / 2f, height / 2f)
            
            // Base radius scaled to screen size and planet radius
            val baseRadius = min(width, height) * 0.28f
            val radiusFactor = when {
                planet.radiusEarth > 8.0 -> 1.4f
                planet.radiusEarth > 3.0 -> 1.25f
                planet.radiusEarth < 0.4 -> 0.7f
                else -> 1.0f
            }
            val planetRadius = (baseRadius * radiusFactor).coerceIn(min(width, height) * 0.15f, min(width, height) * 0.42f)

            // 1. Draw Star Field Background
            starsList.forEach { (xRatio, yRatio, starSize) ->
                val px = xRatio * width
                val py = yRatio * height
                drawCircle(
                    color = Color.White.copy(alpha = 0.5f + sin((px + rotationAngle) * 0.05f).absoluteValue * 0.4f),
                    radius = starSize,
                    center = Offset(px, py)
                )
            }

            // 2. Draw Back-lighting / Star Light Direction Aura
            val starColor = Color(star.type.starColorHex)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(starColor.copy(alpha = 0.15f), Color.Transparent),
                    center = Offset(width * 0.15f, height * 0.2f),
                    radius = width * 0.6f
                )
            )

            // 3. Magnetic Field Lines Overlay (if enabled)
            if (showMagneticField && planet.magneticFieldStrengthGauss > 0.01) {
                val fieldColor = Color(0xFF00E5FF).copy(alpha = 0.4f)
                val fieldCount = 5
                for (i in 1..fieldCount) {
                    val scaleX = planetRadius * (1.3f + i * 0.3f)
                    val scaleY = planetRadius * (0.8f + i * 0.2f)
                    drawOval(
                        color = fieldColor,
                        topLeft = Offset(center.x - scaleX, center.y - scaleY),
                        size = Size(scaleX * 2f, scaleY * 2f),
                        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                    )
                }
            }

            // Total Tilt angle = Planet Axial Tilt + user Y drag
            val totalTilt = planet.axialTiltDegrees + userDragY

            rotate(degrees = totalTilt, pivot = center) {
                // 4. Draw Back Portion of Moons
                drawMoons(
                    center = center,
                    planetRadius = planetRadius,
                    moonCount = planet.moonCount,
                    rotationAngle = rotationAngle,
                    drawFront = false
                )

                // 5. Draw Back Portion of Rings (if enabled)
                if (planet.hasRings) {
                    drawRings(
                        center = center,
                        planetRadius = planetRadius,
                        ringColor = Color(planet.ringColorHex),
                        drawFront = false
                    )
                }

                // 6. Draw Atmosphere Outer Glow
                val atmPressure = planet.atmosphericPressureAtm.toFloat().coerceIn(0.01f, 10f)
                val atmGlowRadius = planetRadius + (12.dp.toPx() * (atmPressure / 1f).coerceIn(0.5f, 2.5f))
                val atmColor = when {
                    planet.atmosphere.oxygenPct > 15f -> Color(0xFF4FC3F7) // Earth Blue
                    planet.atmosphere.carbonDioxidePct > 80f -> Color(0xFFFFB74D) // Venusian Amber
                    planet.atmosphere.methanePct > 1f -> Color(0xFF4DD0E1) // Uranus/Neptune Cyan
                    else -> Color(0xFF90A4AE) // Neutral grey
                }

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(atmColor.copy(alpha = (0.3f * atmPressure).coerceIn(0.1f, 0.6f)), Color.Transparent),
                        center = center,
                        radius = atmGlowRadius
                    ),
                    radius = atmGlowRadius,
                    center = center
                )

                // 7. Render Planet Sphere Body
                val planetBaseColor = Color(planet.baseColorHex)
                val landColor = Color(planet.landColorHex)

                // Base Sphere clip
                val planetPath = Path().apply {
                    addOval(Rect(center.x - planetRadius, center.y - planetRadius, center.x + planetRadius, center.y + planetRadius))
                }

                clipPath(planetPath) {
                    // Solid Ocean / Base Gradient
                    drawRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                planetBaseColor,
                                planetBaseColor.copy(red = (planetBaseColor.red * 0.8f).coerceIn(0f, 1f))
                            )
                        )
                    )

                    // Draw Surface Features (Landmasses / Deserts / Forests)
                    val shiftedAngle = rotationAngle + userDragX
                    val landSegments = 12
                    for (i in 0 until landSegments) {
                        val phase = (shiftedAngle + i * (360f / landSegments)) % 360f
                        val radPhase = Math.toRadians(phase.toDouble())
                        val cosPhase = cos(radPhase).toFloat()
                        val sinPhase = sin(radPhase).toFloat()

                        if (cosPhase > -0.2f) { // Visible hemisphere
                            val xPos = center.x + (sinPhase * planetRadius * 0.85f)
                            val yOffset = ((i * 37) % 100 - 50) / 50f * (planetRadius * 0.6f)
                            val landWidth = (planet.surface.landPct / 100f) * planetRadius * (0.4f + 0.3f * cosPhase)
                            val landHeight = landWidth * 0.7f

                            if (landWidth > 5f) {
                                val featureColor = when {
                                    planet.surface.desertPct > 40f -> Color(0xFFE6C280)
                                    planet.surface.forestPct > 30f -> Color(0xFF2E7D32)
                                    planet.surface.icePct > 50f -> Color(0xFFE0F7FA)
                                    else -> landColor
                                }

                                drawOval(
                                    color = featureColor.copy(alpha = (0.85f * cosPhase).coerceIn(0.2f, 0.95f)),
                                    topLeft = Offset(xPos - landWidth / 2f, center.y + yOffset - landHeight / 2f),
                                    size = Size(landWidth, landHeight)
                                )

                                // Night-side Human Colony City Lights
                                if (planet.humanPopulation > 0L && sinPhase < 0.1f) {
                                    val cityLightsColor = Color(0xFFFFD54F)
                                    drawCircle(
                                        color = cityLightsColor.copy(alpha = 0.8f),
                                        radius = 3.dp.toPx(),
                                        center = Offset(xPos, center.y + yOffset)
                                    )
                                    drawCircle(
                                        color = cityLightsColor.copy(alpha = 0.6f),
                                        radius = 2.dp.toPx(),
                                        center = Offset(xPos + 6f, center.y + yOffset - 4f)
                                    )
                                }
                            }
                        }
                    }

                    // Impact Craters on Surface
                    planet.impactCraters.forEach { crater ->
                        val cx = center.x + (crater.xRatio - 0.5f) * planetRadius * 1.5f
                        val cy = center.y + (crater.yRatio - 0.5f) * planetRadius * 1.5f
                        val craterRadius = crater.radiusDp.dp.toPx()

                        drawCircle(
                            color = Color(0xFF261815),
                            radius = craterRadius,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = Color(0xFFFF5722).copy(alpha = 0.7f),
                            radius = craterRadius * 0.6f,
                            center = Offset(cx, cy),
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }

                    // Ice Caps at Poles
                    if (planet.icePct > 2f) {
                        val capHeight = planetRadius * (planet.icePct / 100f).coerceIn(0.1f, 0.45f)
                        // Top Cap
                        drawRect(
                            color = Color.White.copy(alpha = 0.9f),
                            topLeft = Offset(center.x - planetRadius, center.y - planetRadius),
                            size = Size(planetRadius * 2f, capHeight)
                        )
                        // Bottom Cap
                        drawRect(
                            color = Color.White.copy(alpha = 0.9f),
                            topLeft = Offset(center.x - planetRadius, center.y + planetRadius - capHeight),
                            size = Size(planetRadius * 2f, capHeight)
                        )
                    }

                    // Rotating Clouds Layer
                    if (planet.cloudPct > 2f) {
                        val cloudPhase = (rotationAngle * 1.3f + userDragX) % 360f
                        val cloudCount = 8
                        for (c in 0 until cloudCount) {
                            val cRad = Math.toRadians(((cloudPhase + c * 45f) % 360f).toDouble())
                            val cCos = cos(cRad).toFloat()
                            val cSin = sin(cRad).toFloat()

                            if (cCos > -0.1f) {
                                val cx = center.x + (cSin * planetRadius * 0.9f)
                                val cy = center.y + ((c * 29) % 80 - 40) / 40f * (planetRadius * 0.7f)
                                val cSize = (planet.cloudPct / 100f) * planetRadius * 0.5f

                                drawOval(
                                    color = Color.White.copy(alpha = (0.6f * cCos * (planet.cloudPct / 100f)).coerceIn(0.1f, 0.85f)),
                                    topLeft = Offset(cx - cSize / 2f, cy - cSize / 4f),
                                    size = Size(cSize, cSize * 0.5f)
                                )
                            }
                        }
                    }

                    // Damaged Planet Magma Crack Lines if Health < 60%
                    if (planet.healthPct < 60f) {
                        val magmaColor = Color(0xFFFF3D00).copy(alpha = ((60f - planet.healthPct) / 60f).coerceIn(0.2f, 0.9f))
                        drawLine(
                            color = magmaColor,
                            start = Offset(center.x - planetRadius * 0.5f, center.y - planetRadius * 0.3f),
                            end = Offset(center.x + planetRadius * 0.4f, center.y + planetRadius * 0.2f),
                            strokeWidth = 3.dp.toPx()
                        )
                        drawLine(
                            color = magmaColor,
                            start = Offset(center.x - planetRadius * 0.1f, center.y + planetRadius * 0.1f),
                            end = Offset(center.x + planetRadius * 0.2f, center.y + planetRadius * 0.6f),
                            strokeWidth = 2.5.dp.toPx()
                        )
                    }

                    // 8. 3D Spherical Shadow (Terminator Line from Star Direction)
                    drawRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.4f),
                                Color.Black.copy(alpha = 0.92f)
                            ),
                            startX = center.x - planetRadius,
                            endX = center.x + planetRadius
                        )
                    )
                }

                // PLANETARY FORCE SHIELD RENDER
                if (planet.shieldActive && planet.shieldPowerPct > 0f) {
                    val shieldRadius = planetRadius + 16.dp.toPx()
                    val shieldColor = Color(0xFF00E5FF).copy(alpha = shieldPulseAlpha * (planet.shieldPowerPct / 100f))

                    // Outer Forcefield Glow
                    drawCircle(
                        color = shieldColor,
                        radius = shieldRadius,
                        center = center,
                        style = Stroke(width = 3.5.dp.toPx())
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.Transparent, shieldColor.copy(alpha = 0.25f)),
                            center = center,
                            radius = shieldRadius
                        ),
                        radius = shieldRadius,
                        center = center
                    )
                }

                // ATTACK MISSILE / ASTEROID ANIMATION
                if (activeAttack != null && attackProgress > 0f) {
                    val startX = width * 0.95f
                    val startY = height * 0.05f
                    val targetX = center.x
                    val targetY = center.y

                    val currentX = startX + (targetX - startX) * attackProgress
                    val currentY = startY + (targetY - startY) * attackProgress

                    val projColor = when (activeAttack) {
                        AttackType.MISSILE -> Color(0xFFFF1744)
                        AttackType.ASTEROID -> Color(0xFFFF9100)
                        AttackType.SOLAR_FLARE -> Color(0xFFFFEA00)
                        AttackType.ANTIMATTER -> Color(0xFFD500F9)
                    }

                    // Tail Streak
                    drawLine(
                        color = projColor,
                        start = Offset(startX, startY),
                        end = Offset(currentX, currentY),
                        strokeWidth = 4.dp.toPx()
                    )
                    // Head Projectile
                    drawCircle(
                        color = projColor,
                        radius = 8.dp.toPx(),
                        center = Offset(currentX, currentY)
                    )

                    // Explosion on impact
                    if (attackProgress > 0.85f) {
                        drawCircle(
                            color = projColor.copy(alpha = 0.7f),
                            radius = 45.dp.toPx() * (attackProgress - 0.85f) * 6.6f,
                            center = center
                        )
                    }
                }

                // 9. Draw Front Portion of Rings (if enabled)
                if (planet.hasRings) {
                    drawRings(
                        center = center,
                        planetRadius = planetRadius,
                        ringColor = Color(planet.ringColorHex),
                        drawFront = true
                    )
                }

                // 10. Draw Front Portion of Moons
                drawMoons(
                    center = center,
                    planetRadius = planetRadius,
                    moonCount = planet.moonCount,
                    rotationAngle = rotationAngle,
                    drawFront = true
                )
            }
        }
        
        // Interactive Instruction Banner & Status Badges
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (planet.shieldActive) {
                Box(
                    modifier = Modifier
                        .background(Color(0xFF0284C7).copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        "🛡️ SHIELD ACTIVE (${planet.shieldPowerPct.toInt()}%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            if (planet.healthPct < 100f) {
                Box(
                    modifier = Modifier
                        .background(Color(0xFFDC2626).copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        "❤️ INTEGRITY: ${planet.healthPct.toInt()}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Text(
                text = "Touch and drag to rotate view",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.4f)
            )
        }
    }
}

private fun DrawScope.drawRings(
    center: Offset,
    planetRadius: Float,
    ringColor: Color,
    drawFront: Boolean
) {
    val ringWidth = planetRadius * 2.6f
    val ringHeight = planetRadius * 0.6f

    val path = Path().apply {
        addOval(Rect(center.x - ringWidth / 2f, center.y - ringHeight / 2f, center.x + ringWidth / 2f, center.y + ringHeight / 2f))
    }

    clipRect(
        left = 0f,
        top = if (drawFront) center.y else 0f,
        right = size.width,
        bottom = if (drawFront) size.height else center.y
    ) {
        drawOval(
            color = ringColor.copy(alpha = 0.8f),
            topLeft = Offset(center.x - ringWidth / 2f, center.y - ringHeight / 2f),
            size = Size(ringWidth, ringHeight),
            style = Stroke(width = planetRadius * 0.45f)
        )
        
        // Inner ring line detail
        drawOval(
            color = Color.White.copy(alpha = 0.3f),
            topLeft = Offset(center.x - ringWidth * 0.42f, center.y - ringHeight * 0.42f),
            size = Size(ringWidth * 0.84f, ringHeight * 0.84f),
            style = Stroke(width = 2f)
        )
    }
}

private fun DrawScope.drawMoons(
    center: Offset,
    planetRadius: Float,
    moonCount: Int,
    rotationAngle: Float,
    drawFront: Boolean
) {
    if (moonCount <= 0) return
    val displayedMoons = moonCount.coerceAtMost(6)

    for (m in 0 until displayedMoons) {
        val orbitRadiusX = planetRadius * (1.6f + m * 0.5f)
        val orbitRadiusY = orbitRadiusX * 0.35f
        val moonAngle = (rotationAngle * (1f + m * 0.3f) + m * (360f / displayedMoons)) % 360f
        val rad = Math.toRadians(moonAngle.toDouble())
        val mx = center.x + (cos(rad) * orbitRadiusX).toFloat()
        val my = center.y + (sin(rad) * orbitRadiusY).toFloat()

        val isFront = sin(rad) >= 0

        if (isFront == drawFront) {
            val moonRadius = (planetRadius * 0.08f).coerceAtLeast(5f)
            
            // Draw orbit line behind
            if (!drawFront && m == 0) {
                drawOval(
                    color = Color.White.copy(alpha = 0.15f),
                    topLeft = Offset(center.x - orbitRadiusX, center.y - orbitRadiusY),
                    size = Size(orbitRadiusX * 2f, orbitRadiusY * 2f),
                    style = Stroke(width = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f))
                )
            }

            // Draw Moon
            drawCircle(
                color = Color(0xFFD6D6D6),
                radius = moonRadius,
                center = Offset(mx, my)
            )
            // Moon shadow
            drawCircle(
                color = Color.Black.copy(alpha = 0.5f),
                radius = moonRadius,
                center = Offset(mx + 2f, my)
            )
        }
    }
}
