package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlanetData
import com.example.model.StarData

@Composable
fun PlanetSelectorDropdown(
    currentPlanet: PlanetData,
    savedPlanets: List<PlanetData>,
    onSelectPlanet: (PlanetData) -> Unit,
    onCreateCustomPlanet: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(
            onClick = { expanded = true },
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = Color(0xFF1E293B),
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Public, contentDescription = "Current Planet", tint = Color(0xFF38BDF8))
                Text(currentPlanet.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                .width(220.dp)
        ) {
            DropdownMenuItem(
                text = { Text("+ Create Custom Planet", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold) },
                onClick = {
                    expanded = false
                    onCreateCustomPlanet()
                }
            )

            Divider(color = Color(0xFF334155))

            Text("PRESETS & SOLAR SYSTEM", fontSize = 10.sp, color = Color(0xFF64748B), modifier = Modifier.padding(12.dp, 6.dp))

            PlanetData.ALL_PRESETS.forEach { preset ->
                DropdownMenuItem(
                    text = { Text(preset.name, color = Color.White) },
                    onClick = {
                        expanded = false
                        onSelectPlanet(preset)
                    }
                )
            }

            if (savedPlanets.isNotEmpty()) {
                Divider(color = Color(0xFF334155))
                Text("MY SAVED PLANETS", fontSize = 10.sp, color = Color(0xFF38BDF8), modifier = Modifier.padding(12.dp, 6.dp))
                savedPlanets.forEach { saved ->
                    DropdownMenuItem(
                        text = { Text(saved.name, color = Color(0xFFE2E8F0)) },
                        onClick = {
                            expanded = false
                            onSelectPlanet(saved)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PlanetComparisonDialog(
    planetA: PlanetData,
    allPlanets: List<PlanetData>,
    star: StarData,
    onDismiss: () -> Unit
) {
    var selectedPlanetBId by remember { mutableStateOf(allPlanets.firstOrNull { it.id != planetA.id }?.id ?: planetA.id) }
    val planetB = allPlanets.find { it.id == selectedPlanetBId } ?: planetA

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        title = {
            Text("Compare Planetary Metrics", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Selector for Planet B
                Text("Select Planet to Compare against:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                if (allPlanets.isNotEmpty()) {
                    val tabIdx = allPlanets.indexOfFirst { it.id == selectedPlanetBId }
                        .let { if (it < 0) 0 else it }
                        .coerceIn(0, allPlanets.size - 1)
                    ScrollableTabRow(
                        selectedTabIndex = tabIdx,
                        containerColor = Color(0xFF1E293B),
                        contentColor = Color(0xFF38BDF8)
                    ) {
                        allPlanets.forEach { p ->
                            Tab(
                                selected = p.id == selectedPlanetBId,
                                onClick = { selectedPlanetBId = p.id },
                                text = { Text(p.name, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Divider(color = Color(0xFF334155))

                // Comparison Table
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 300.dp)) {
                    item {
                        CompareRowHeader(planetA.name, planetB.name)
                    }
                    item {
                        val gA = planetA.surfaceGravityEarth
                        val gB = planetB.surfaceGravityEarth
                        CompareMetricRow("Surface Gravity", "%.2f g".format(gA), "%.2f g".format(gB))
                    }
                    item {
                        val tA = planetA.calculateEquilibriumTempKelvin(star.luminositySolar) - 273.15
                        val tB = planetB.calculateEquilibriumTempKelvin(star.luminositySolar) - 273.15
                        CompareMetricRow("Est. Temperature", "%.1f°C".format(tA), "%.1f°C".format(tB))
                    }
                    item {
                        val hA = planetA.calculateHabitabilityScore(star).overallScorePct
                        val hB = planetB.calculateHabitabilityScore(star).overallScorePct
                        CompareMetricRow("Habitability Score", "$hA%", "$hB%")
                    }
                    item {
                        CompareMetricRow("Mass (Earths)", "%.2f".format(planetA.massEarth), "%.2f".format(planetB.massEarth))
                    }
                    item {
                        CompareMetricRow("Radius (Earths)", "%.2f".format(planetA.radiusEarth), "%.2f".format(planetB.radiusEarth))
                    }
                    item {
                        CompareMetricRow("Atm. Pressure", "%.2f atm".format(planetA.atmosphericPressureAtm), "%.2f atm".format(planetB.atmosphericPressureAtm))
                    }
                    item {
                        CompareMetricRow("Primary Atmosphere", "O₂ %.0f%% / N₂ %.0f%%".format(planetA.atmosphere.oxygenPct, planetA.atmosphere.nitrogenPct), "O₂ %.0f%% / N₂ %.0f%%".format(planetB.atmosphere.oxygenPct, planetB.atmosphere.nitrogenPct))
                    }
                    item {
                        CompareMetricRow("Liquid Water", "%.0f%%".format(planetA.waterPct), "%.0f%%".format(planetB.waterPct))
                    }
                    item {
                        CompareMetricRow("Moons / Rings", "${planetA.moonCount} moons / ${if (planetA.hasRings) "Rings" else "No Rings"}", "${planetB.moonCount} moons / ${if (planetB.hasRings) "Rings" else "No Rings"}")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Close Comparison")
            }
        }
    )
}

@Composable
private fun CompareRowHeader(nameA: String, nameB: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1E293B), RoundedCornerShape(6.dp))
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Metric", fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), fontSize = 11.sp, modifier = Modifier.weight(1.2f))
        Text(nameA, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(nameB, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun CompareMetricRow(metric: String, valA: String, valB: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(metric, color = Color(0xFF94A3B8), fontSize = 11.sp, modifier = Modifier.weight(1.2f))
        Text(valA, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(valB, color = Color(0xFFE2E8F0), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
    }
}

@Composable
fun SaveOrRenameDialog(
    initialName: String,
    title: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        title = { Text(title, color = Color(0xFF38BDF8)) },
        text = {
            Column {
                Text("Enter planet name:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF38BDF8)
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) onConfirm(text.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}
