package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.PlanetData
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulatorScreen(viewModel: SimulatorViewModel) {
    val currentPlanet by viewModel.currentPlanet.collectAsStateWithLifecycle()
    val currentStar by viewModel.currentStar.collectAsStateWithLifecycle()
    val savedPlanets by viewModel.savedPlanets.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val simulationSpeed by viewModel.simulationSpeed.collectAsStateWithLifecycle()
    val daysElapsed by viewModel.simulatedDaysElapsed.collectAsStateWithLifecycle()
    val showMagneticField by viewModel.showMagneticField.collectAsStateWithLifecycle()
    val activeAttack by viewModel.activeAttack.collectAsStateWithLifecycle()
    val eventLogs by viewModel.eventLogs.collectAsStateWithLifecycle()
    val colonyStatusText by viewModel.colonyStatusText.collectAsStateWithLifecycle()

    var showSaveDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showCompareDialog by remember { mutableStateOf(false) }

    var leftPanelExpanded by remember { mutableStateOf(true) }
    var rightPanelExpanded by remember { mutableStateOf(true) }

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.screenWidthDp > configuration.screenHeightDp

    val allPlanetsForCompare = remember(savedPlanets) {
        (PlanetData.ALL_PRESETS + savedPlanets).distinctBy { it.id }
    }

    Scaffold(
        containerColor = Color(0xFF030712), // Deep Space Navy
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "WHAT IF?",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF38BDF8)
                        )
                        Text(
                            "UNIVERSE SIMULATOR",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF94A3B8)
                        )
                    }
                },
                actions = {
                    PlanetSelectorDropdown(
                        currentPlanet = currentPlanet,
                        savedPlanets = savedPlanets,
                        onSelectPlanet = { viewModel.selectPlanet(it) },
                        onCreateCustomPlanet = { viewModel.createCustomPlanet() }
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(onClick = { leftPanelExpanded = !leftPanelExpanded }) {
                        Icon(
                            Icons.Default.Analytics,
                            contentDescription = "Toggle Metrics",
                            tint = if (leftPanelExpanded) Color(0xFF38BDF8) else Color(0xFF64748B)
                        )
                    }

                    IconButton(onClick = { rightPanelExpanded = !rightPanelExpanded }) {
                        Icon(
                            Icons.Default.Tune,
                            contentDescription = "Toggle Controls",
                            tint = if (rightPanelExpanded) Color(0xFF38BDF8) else Color(0xFF64748B)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A).copy(alpha = 0.95f),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            SimulationControlsBar(
                isPlaying = isPlaying,
                speed = simulationSpeed,
                daysElapsed = daysElapsed,
                planet = currentPlanet,
                onTogglePlayPause = { viewModel.togglePlayPause() },
                onResetTime = { viewModel.resetSimulationTime() },
                onSetSpeed = { viewModel.setSimulationSpeed(it) },
                onOpenSaveDialog = { showSaveDialog = true },
                onOpenRenameDialog = { showRenameDialog = true },
                onDuplicate = { viewModel.duplicateCurrentPlanet() },
                onDelete = { viewModel.deleteCurrentPlanet() },
                onOpenCompareDialog = { showCompareDialog = true },
                onResetPlanetDefaults = { viewModel.resetToDefaultPreset() }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isLandscape) {
                // Wide / Landscape Layout: Left Metrics, Center Canvas, Right Inspector
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AnimatedVisibility(visible = leftPanelExpanded, modifier = Modifier.weight(0.28f)) {
                        MetricsPanel(
                            planet = currentPlanet,
                            star = currentStar,
                            modifier = Modifier.fillMaxHeight()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(if (leftPanelExpanded && rightPanelExpanded) 0.44f else if (leftPanelExpanded || rightPanelExpanded) 0.65f else 1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        PlanetCanvas(
                            planet = currentPlanet,
                            star = currentStar,
                            simulationSpeed = simulationSpeed,
                            isPlaying = isPlaying,
                            simulatedDaysElapsed = daysElapsed,
                            showMagneticField = showMagneticField,
                            activeAttack = activeAttack,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    AnimatedVisibility(visible = rightPanelExpanded, modifier = Modifier.weight(0.28f)) {
                        ParameterInspectorPanel(
                            planet = currentPlanet,
                            star = currentStar,
                            showMagneticField = showMagneticField,
                            colonyStatusText = colonyStatusText,
                            eventLogs = eventLogs,
                            onGeneratePlanet = { viewModel.generatePlanet() },
                            onLaunchAttack = { viewModel.launchAttack(it) },
                            onToggleShield = { viewModel.toggleShield() },
                            onDeployHumans = { viewModel.deployHumans(it) },
                            onRepairPlanet = { viewModel.repairPlanet() },
                            onUpdatePlanet = { viewModel.updateCurrentPlanet(it) },
                            onUpdateStar = { viewModel.updateCurrentStar(it) },
                            onToggleMagneticField = { viewModel.toggleMagneticField(it) },
                            modifier = Modifier.fillMaxHeight()
                        )
                    }
                }
            } else {
                // Portrait Layout: Canvas top/center, overlays or stacked panels
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Center Visualization Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.42f),
                        contentAlignment = Alignment.Center
                    ) {
                        PlanetCanvas(
                            planet = currentPlanet,
                            star = currentStar,
                            simulationSpeed = simulationSpeed,
                            isPlaying = isPlaying,
                            simulatedDaysElapsed = daysElapsed,
                            showMagneticField = showMagneticField,
                            activeAttack = activeAttack,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Lower Split Panels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.58f),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (leftPanelExpanded) {
                            MetricsPanel(
                                planet = currentPlanet,
                                star = currentStar,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }

                        if (rightPanelExpanded) {
                            ParameterInspectorPanel(
                                planet = currentPlanet,
                                star = currentStar,
                                showMagneticField = showMagneticField,
                                colonyStatusText = colonyStatusText,
                                eventLogs = eventLogs,
                                onGeneratePlanet = { viewModel.generatePlanet() },
                                onLaunchAttack = { viewModel.launchAttack(it) },
                                onToggleShield = { viewModel.toggleShield() },
                                onDeployHumans = { viewModel.deployHumans(it) },
                                onRepairPlanet = { viewModel.repairPlanet() },
                                onUpdatePlanet = { viewModel.updateCurrentPlanet(it) },
                                onUpdateStar = { viewModel.updateCurrentStar(it) },
                                onToggleMagneticField = { viewModel.toggleMagneticField(it) },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialogs
    if (showSaveDialog) {
        SaveOrRenameDialog(
            initialName = currentPlanet.name,
            title = "Save Planet Scenario",
            onConfirm = {
                viewModel.saveCurrentPlanet(it)
                showSaveDialog = false
            },
            onDismiss = { showSaveDialog = false }
        )
    }

    if (showRenameDialog) {
        SaveOrRenameDialog(
            initialName = currentPlanet.name,
            title = "Rename Planet",
            onConfirm = {
                viewModel.renameCurrentPlanet(it)
                showRenameDialog = false
            },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showCompareDialog) {
        PlanetComparisonDialog(
            planetA = currentPlanet,
            allPlanets = allPlanetsForCompare,
            star = currentStar,
            onDismiss = { showCompareDialog = false }
        )
    }
}
