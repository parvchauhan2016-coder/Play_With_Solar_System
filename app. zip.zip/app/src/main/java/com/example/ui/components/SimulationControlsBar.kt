package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlanetData

@Composable
fun SimulationControlsBar(
    isPlaying: Boolean,
    speed: Float,
    daysElapsed: Double,
    planet: PlanetData,
    onTogglePlayPause: () -> Unit,
    onResetTime: () -> Unit,
    onSetSpeed: (Float) -> Unit,
    onOpenSaveDialog: () -> Unit,
    onOpenRenameDialog: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onOpenCompareDialog: () -> Unit,
    onResetPlanetDefaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speeds = listOf(0.5f, 1f, 10f, 100f, 1000f)

    Column(
        modifier = modifier
            .background(Color(0xFF0F172A).copy(alpha = 0.95f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Top Row: Play / Pause, Reset, Elapsed Time, Speed Multipliers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Play/Pause & Reset
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(
                    onClick = onTogglePlayPause,
                    modifier = Modifier.background(Color(0xFF0284C7), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause Simulation" else "Play Simulation",
                        tint = Color.White
                    )
                }

                IconButton(
                    onClick = onResetTime,
                    modifier = Modifier.background(Color(0xFF334155), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset Time", tint = Color.White)
                }

                // Elapsed Time Counter
                Column {
                    Text("TIME ELAPSED", fontSize = 9.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                    val years = daysElapsed / 365.25
                    Text(
                        if (years >= 1.0) "%.2f Years".format(years) else "%.1f Days".format(daysElapsed),
                        fontSize = 13.sp,
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Speed Selector Buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                speeds.forEach { s ->
                    val isSelected = speed == s
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSetSpeed(s) },
                        label = { Text("${if (s < 1f) s else s.toInt()}x", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0284C7),
                            selectedLabelColor = Color.White,
                            containerColor = Color(0xFF1E293B),
                            labelColor = Color(0xFF94A3B8)
                        )
                    )
                }
            }
        }

        // Bottom Row: Presets & Action Tools (Save, Rename, Duplicate, Delete, Compare, Reset)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Preset Badges
            val presets = listOf(
                "Earth" to PlanetData.EARTH,
                "Super-Earth" to PlanetData.SUPER_EARTH,
                "Desert World" to PlanetData.DESERT_WORLD,
                "Ice World" to PlanetData.ICE_WORLD,
                "Ocean World" to PlanetData.OCEAN_WORLD,
                "High-Gravity" to PlanetData.HIGH_GRAVITY_WORLD
            )

            presets.forEach { (label, data) ->
                SuggestionChip(
                    onClick = { onResetPlanetDefaults() }, // or load preset
                    label = { Text(label, fontSize = 10.sp, color = Color(0xFFCBD5E1)) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.padding(end = 4.dp)
                )
            }

            Divider(modifier = Modifier.width(1.dp).height(24.dp).padding(horizontal = 4.dp), color = Color(0xFF334155))

            // Management Action Buttons
            IconButton(onClick = onOpenSaveDialog, modifier = Modifier.padding(end = 4.dp)) {
                Icon(Icons.Default.Save, contentDescription = "Save Planet", tint = Color(0xFF34D399), modifier = Modifier.size(20.dp))
            }

            IconButton(onClick = onOpenRenameDialog, modifier = Modifier.padding(end = 4.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Rename Planet", tint = Color(0xFF38BDF8), modifier = Modifier.size(20.dp))
            }

            IconButton(onClick = onDuplicate, modifier = Modifier.padding(end = 4.dp)) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate Planet", tint = Color(0xFFA78BFA), modifier = Modifier.size(20.dp))
            }

            IconButton(onClick = onOpenCompareDialog, modifier = Modifier.padding(end = 4.dp)) {
                Icon(Icons.Default.Compare, contentDescription = "Compare Planets", tint = Color(0xFFFBBF24), modifier = Modifier.size(20.dp))
            }

            IconButton(onClick = onResetPlanetDefaults, modifier = Modifier.padding(end = 4.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset Defaults", tint = Color(0xFF94A3B8), modifier = Modifier.size(20.dp))
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Planet", tint = Color(0xFFF87171), modifier = Modifier.size(20.dp))
            }
        }
    }
}
