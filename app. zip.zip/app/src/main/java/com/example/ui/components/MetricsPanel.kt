package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlanetData
import com.example.model.StarData
import kotlin.math.roundToInt

@Composable
fun MetricsPanel(
    planet: PlanetData,
    star: StarData,
    modifier: Modifier = Modifier
) {
    val orbitalDays = planet.calculateOrbitalPeriodDays(star.massSolar)
    val tempK = planet.calculateEquilibriumTempKelvin(star.luminositySolar)
    val tempC = tempK - 273.15
    val tempF = (tempC * 9 / 5) + 32
    val habitability = planet.calculateHabitabilityScore(star)

    val habitabilityProgress by animateFloatAsState(
        targetValue = habitability.overallScorePct / 100f,
        label = "HabitabilityProgress"
    )

    Column(
        modifier = modifier
            .background(Color(0xFF0F172A).copy(alpha = 0.92f), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Habitability Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("HABITABILITY INDEX", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
                Text(habitability.statusText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = getHabitabilityColor(habitability.overallScorePct))
            }

            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { habitabilityProgress },
                    modifier = Modifier.size(46.dp),
                    color = getHabitabilityColor(habitability.overallScorePct),
                    trackColor = Color(0xFF334155),
                    strokeWidth = 5.dp
                )
                Text(
                    "${habitability.overallScorePct}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        }

        Divider(color = Color(0xFF334155))

        // Grid of Calculated Physics Values
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricBox(
                title = "Est. Temp",
                value = "%.1f°C".format(tempC),
                subtitle = "%.0f K / %.0f°F".format(tempK, tempF),
                icon = Icons.Default.Thermostat,
                tint = if (tempC in -10.0..35.0) Color(0xFF34D399) else Color(0xFFF87171),
                modifier = Modifier.weight(1f)
            )

            MetricBox(
                title = "Orbital Period",
                value = if (orbitalDays > 365.25) "%.2f Yrs".format(orbitalDays / 365.25) else "%.1f Days".format(orbitalDays),
                subtitle = "%.2f AU".format(planet.distanceFromStarAu),
                icon = Icons.Default.Sync,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f)
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricBox(
                title = "Gravity",
                value = "%.2f g".format(planet.surfaceGravityEarth),
                subtitle = "%.1f m/s²".format(planet.surfaceGravityMs2),
                icon = Icons.Default.Speed,
                tint = Color(0xFFA78BFA),
                modifier = Modifier.weight(1f)
            )

            MetricBox(
                title = "Day Cycle",
                value = "%.1f Hrs".format(planet.rotationPeriodHours),
                subtitle = "Tilt: %.1f°".format(planet.axialTiltDegrees),
                icon = Icons.Default.Schedule,
                tint = Color(0xFFFBBF24),
                modifier = Modifier.weight(1f)
            )
        }

        // Habitability Breakdown Mini Bars
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Habitability Factors", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
            FactorBar("Temperature", habitability.tempScore)
            FactorBar("Atmosphere", habitability.atmosphereScore)
            FactorBar("Liquid Water", habitability.waterScore)
            FactorBar("Magnetosphere Shield", habitability.magneticScore)
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(14.dp))
                Text(title, fontSize = 10.sp, color = Color(0xFF94A3B8))
            }
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(subtitle, fontSize = 10.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
private fun FactorBar(label: String, scorePct: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 10.sp, color = Color(0xFFCBD5E1))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LinearProgressIndicator(
                progress = { scorePct / 100f },
                modifier = Modifier
                    .width(80.dp)
                    .height(4.dp)
                    .clip(CircleShape),
                color = getHabitabilityColor(scorePct),
                trackColor = Color(0xFF334155)
            )
            Text("$scorePct%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

private fun getHabitabilityColor(scorePct: Int): Color {
    return when {
        scorePct >= 80 -> Color(0xFF34D399) // Emerald
        scorePct >= 50 -> Color(0xFFFBBF24) // Amber
        scorePct >= 25 -> Color(0xFFFB923C) // Orange
        else -> Color(0xFFF87171) // Red
    }
}
