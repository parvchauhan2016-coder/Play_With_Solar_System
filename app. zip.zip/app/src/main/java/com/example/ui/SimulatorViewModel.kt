package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.PlanetRepository
import com.example.model.CraterPoint
import com.example.model.PlanetData
import com.example.model.StarData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max
import kotlin.random.Random

enum class AttackType {
    MISSILE, ASTEROID, SOLAR_FLARE, ANTIMATTER
}

class SimulatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PlanetRepository

    init {
        val dao = AppDatabase.getDatabase(application).planetDao()
        repository = PlanetRepository(dao)
        observeSavedPlanets()
        startSimulationTicker()
        addLog("🌌 System Initialized: Ready to generate and simulate worlds!")
    }

    private val _currentPlanet = MutableStateFlow(PlanetData.EARTH)
    val currentPlanet: StateFlow<PlanetData> = _currentPlanet.asStateFlow()

    private val _currentStar = MutableStateFlow(StarData())
    val currentStar: StateFlow<StarData> = _currentStar.asStateFlow()

    private val _savedPlanets = MutableStateFlow<List<PlanetData>>(emptyList())
    val savedPlanets: StateFlow<List<PlanetData>> = _savedPlanets.asStateFlow()

    // Game & Attack Animation State
    private val _activeAttack = MutableStateFlow<AttackType?>(null)
    val activeAttack: StateFlow<AttackType?> = _activeAttack.asStateFlow()

    private val _eventLogs = MutableStateFlow<List<String>>(emptyList())
    val eventLogs: StateFlow<List<String>> = _eventLogs.asStateFlow()

    private val _colonyStatusText = MutableStateFlow("🌍 Planet Ready for Generation")
    val colonyStatusText: StateFlow<String> = _colonyStatusText.asStateFlow()

    // Simulation Controls State
    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _simulationSpeed = MutableStateFlow(1f) // 0.5x, 1x, 10x, 100x, 1000x
    val simulationSpeed: StateFlow<Float> = _simulationSpeed.asStateFlow()

    private val _simulatedDaysElapsed = MutableStateFlow(0.0)
    val simulatedDaysElapsed: StateFlow<Double> = _simulatedDaysElapsed.asStateFlow()

    private val _showMagneticField = MutableStateFlow(false)
    val showMagneticField: StateFlow<Boolean> = _showMagneticField.asStateFlow()

    private var tickerJob: Job? = null
    private var tickCount = 0

    private fun addLog(msg: String) {
        val newLogs = (_eventLogs.value + msg).takeLast(25)
        _eventLogs.value = newLogs
    }

    private fun observeSavedPlanets() {
        viewModelScope.launch {
            repository.savedPlanets.collect { list ->
                _savedPlanets.value = list
            }
        }
    }

    private fun startSimulationTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                delay(50) // 20 FPS update loop
                if (_isPlaying.value) {
                    val dtDays = (0.05 * _simulationSpeed.value)
                    _simulatedDaysElapsed.value += dtDays

                    tickCount++
                    if (tickCount % 20 == 0) { // Every 1 second
                        simulateHumanColonyTick()
                    }
                }
            }
        }
    }

    private fun simulateHumanColonyTick() {
        val p = _currentPlanet.value
        if (p.humanPopulation <= 0L) {
            _colonyStatusText.value = "👨‍🚀 No Humans Present on Planet"
            return
        }

        val habitability = p.calculateHabitabilityScore(_currentStar.value)
        val score = habitability.overallScorePct
        val tempK = p.calculateEquilibriumTempKelvin(_currentStar.value.luminositySolar)
        val tempC = tempK - 273.15

        val updatedPop: Long
        val status: String

        if (p.healthPct <= 5f) {
            updatedPop = 0L
            status = "💀 PLANET DESTROYED: Colony extinct!"
            addLog("🚨 CRITICAL: Planetary structural failure vaporized human colony!")
        } else if (score >= 70) {
            // Growth
            val growth = (p.humanPopulation * 0.002).toLong().coerceAtLeast(100L)
            updatedPop = p.humanPopulation + growth
            status = "🌱 Flourishing Colony (%s humans) - Optimal Environment".format(formatNumber(updatedPop))
        } else if (score >= 35) {
            status = "⚠️ Colony Struggling (%s humans) - Suboptimal Habitat".format(formatNumber(p.humanPopulation))
            updatedPop = p.humanPopulation
        } else {
            // Mortality
            val lossRatio = when {
                tempC < -60 -> 0.05
                tempC > 90 -> 0.08
                p.atmosphere.oxygenPct < 5f -> 0.07
                p.surfaceGravityEarth > 3.0 -> 0.04
                else -> 0.03
            }
            val loss = (p.humanPopulation * lossRatio).toLong().coerceAtLeast(1000L)
            updatedPop = max(0L, p.humanPopulation - loss)

            val reason = when {
                tempC < -60 -> "Freezing Ice Age (-%.0f°C)".format(tempC)
                tempC > 90 -> "Scorching Heat (%.0f°C)".format(tempC)
                p.atmosphere.oxygenPct < 5f -> "Oxygen Deprivation (%.1f%% O2)".format(p.atmosphere.oxygenPct)
                else -> "Lethal Atmospheric Conditions"
            }

            status = if (updatedPop == 0L) {
                "💀 EXTINCTION EVENT: Colony wiped out by $reason"
            } else {
                "🚨 EXTINCTION RISK: Dying off due to $reason (%s alive)".format(formatNumber(updatedPop))
            }
        }

        _colonyStatusText.value = status
        if (updatedPop != p.humanPopulation) {
            _currentPlanet.value = p.copy(humanPopulation = updatedPop)
        }
    }

    private fun formatNumber(num: Long): String {
        return when {
            num >= 1_000_000_000 -> "%.2f Billion".format(num / 1_000_000_000.0)
            num >= 1_000_000 -> "%.1f Million".format(num / 1_000_000.0)
            num >= 1_000 -> "%.1f Thousand".format(num / 1_000.0)
            else -> num.toString()
        }
    }

    // GAME & INTERACTIVE USER ACTIONS

    fun generatePlanet() {
        val p = _currentPlanet.value
        _currentPlanet.value = p.copy(
            isGenerated = true,
            healthPct = 100f,
            shieldPowerPct = 100f,
            impactCraters = emptyList()
        )
        addLog("✨ WORLD GENERATED: ${p.name} instantiated into orbit around ${_currentStar.value.name}!")
        addLog("🌍 Surface Area: ${p.surface.oceanPct.toInt()}% Oceans, ${p.surface.landPct.toInt()}% Continents, ${p.surface.forestPct.toInt()}% Forests.")
        _colonyStatusText.value = "✨ World Successfully Spawned & Live!"
    }

    fun launchAttack(type: AttackType) {
        viewModelScope.launch {
            _activeAttack.value = type
            val p = _currentPlanet.value

            if (p.shieldActive && p.shieldPowerPct > 0f) {
                // Shield absorbs attack
                val shieldDrain = when (type) {
                    AttackType.MISSILE -> 30f
                    AttackType.ASTEROID -> 60f
                    AttackType.SOLAR_FLARE -> 40f
                    AttackType.ANTIMATTER -> 90f
                }
                val newShieldPower = max(0f, p.shieldPowerPct - shieldDrain)
                val shieldCollapsed = newShieldPower <= 0f

                _currentPlanet.value = p.copy(
                    shieldPowerPct = newShieldPower,
                    shieldActive = !shieldCollapsed
                )

                if (shieldCollapsed) {
                    addLog("🛡️💥 PLANETARY SHIELD OVERLOADED & BROKEN by $type impact!")
                } else {
                    addLog("🛡️ SHIELD DEFENDED PLANET! Intercepted $type (Shield power: ${newShieldPower.toInt()}%)")
                }
            } else {
                // Direct strike on planet
                val healthDmg = when (type) {
                    AttackType.MISSILE -> 25f
                    AttackType.ASTEROID -> 45f
                    AttackType.SOLAR_FLARE -> 15f
                    AttackType.ANTIMATTER -> 70f
                }
                val newHealth = max(0f, p.healthPct - healthDmg)

                // Craters
                val newCraters = p.impactCraters + CraterPoint(
                    xRatio = Random.nextFloat() * 0.7f + 0.15f,
                    yRatio = Random.nextFloat() * 0.7f + 0.15f,
                    radiusDp = Random.nextFloat() * 18f + 10f
                )

                // Human casualties
                val casualtyPct = when (type) {
                    AttackType.MISSILE -> 0.30
                    AttackType.ASTEROID -> 0.60
                    AttackType.SOLAR_FLARE -> 0.20
                    AttackType.ANTIMATTER -> 0.90
                }
                val casualties = (p.humanPopulation * casualtyPct).toLong()
                val newPop = max(0L, p.humanPopulation - casualties)

                _currentPlanet.value = p.copy(
                    healthPct = newHealth,
                    impactCraters = newCraters,
                    humanPopulation = newPop
                )

                addLog("💥 DIRECT IMPACT ($type)! Health: ${newHealth.toInt()}% (-${healthDmg.toInt()}%). Casualties: ${formatNumber(casualties)}!")
            }

            delay(1200) // Attack animation duration
            _activeAttack.value = null
        }
    }

    fun toggleShield() {
        val p = _currentPlanet.value
        val newState = !p.shieldActive
        _currentPlanet.value = p.copy(
            shieldActive = newState,
            shieldPowerPct = if (newState) 100f else p.shieldPowerPct
        )
        if (newState) {
            addLog("🛡️ Planetary Energy Force Shield DEPLOYED (100% Barrier Active)")
        } else {
            addLog("⚠️ Planetary Shield DISENGAGED")
        }
    }

    fun deployHumans(count: Long) {
        val p = _currentPlanet.value
        val updatedPop = p.humanPopulation + count
        _currentPlanet.value = p.copy(humanPopulation = updatedPop)
        addLog("👨‍🚀 DEPLOYED ${formatNumber(count)} Human Colonists to ${p.name}! Total Population: ${formatNumber(updatedPop)}")
    }

    fun repairPlanet() {
        val p = _currentPlanet.value
        _currentPlanet.value = p.copy(
            healthPct = 100f,
            shieldPowerPct = 100f,
            impactCraters = emptyList()
        )
        addLog("🔧 REPAIRED PLANET: Surface craters healed, integrity restored to 100%!")
    }

    fun togglePlayPause() {
        _isPlaying.value = !_isPlaying.value
    }

    fun setSimulationSpeed(speed: Float) {
        _simulationSpeed.value = speed
    }

    fun resetSimulationTime() {
        _simulatedDaysElapsed.value = 0.0
    }

    fun toggleMagneticField(show: Boolean) {
        _showMagneticField.value = show
    }

    fun selectPlanet(planet: PlanetData) {
        _currentPlanet.value = planet
        addLog("🪐 Loaded Planet Scenario: ${planet.name}")
    }

    fun createCustomPlanet() {
        val customPlanet = PlanetData(
            id = "custom_" + UUID.randomUUID().toString().take(6),
            name = "New Custom World",
            isPreset = false,
            massEarth = 1.0,
            radiusEarth = 1.0,
            distanceFromStarAu = 1.0,
            rotationPeriodHours = 24.0,
            baseColorHex = 0xFF8A2BE2,
            landColorHex = 0xFF228B22,
            isGenerated = false
        )
        _currentPlanet.value = customPlanet
        addLog("🛠️ Created new Custom World template. Customise surface area and click GENERATE PLANET!")
    }

    fun updateCurrentPlanet(planet: PlanetData) {
        _currentPlanet.value = planet
    }

    fun updateCurrentStar(star: StarData) {
        _currentStar.value = star
    }

    fun resetToDefaultPreset() {
        val currentId = _currentPlanet.value.id
        val preset = PlanetData.ALL_PRESETS.find { it.id == currentId } ?: PlanetData.EARTH
        _currentPlanet.value = preset
        addLog("🔄 Reset ${preset.name} to default astrophysical parameters.")
    }

    fun saveCurrentPlanet(name: String) {
        viewModelScope.launch {
            val toSave = _currentPlanet.value.copy(
                id = if (_currentPlanet.value.isPreset) "saved_" + UUID.randomUUID().toString().take(6) else _currentPlanet.value.id,
                name = name,
                isPreset = false
            )
            _currentPlanet.value = toSave
            repository.savePlanet(toSave)
            addLog("💾 Saved world preset: $name")
        }
    }

    fun duplicateCurrentPlanet() {
        viewModelScope.launch {
            val newCopy = _currentPlanet.value.copy(
                id = "copy_" + UUID.randomUUID().toString().take(6),
                name = "${_currentPlanet.value.name} (Copy)",
                isPreset = false
            )
            _currentPlanet.value = newCopy
            repository.savePlanet(newCopy)
            addLog("📋 Duplicated world: ${newCopy.name}")
        }
    }

    fun renameCurrentPlanet(newName: String) {
        val updated = _currentPlanet.value.copy(name = newName)
        _currentPlanet.value = updated
        if (!updated.isPreset) {
            viewModelScope.launch {
                repository.savePlanet(updated)
            }
        }
    }

    fun deleteCurrentPlanet() {
        val target = _currentPlanet.value
        if (!target.isPreset) {
            viewModelScope.launch {
                repository.deletePlanet(target.id)
                _currentPlanet.value = PlanetData.EARTH
            }
        } else {
            _currentPlanet.value = PlanetData.EARTH
        }
        addLog("🗑️ Deleted world scenario: ${target.name}")
    }
}

