package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PlanetDao {
    @Query("SELECT * FROM saved_planets ORDER BY name ASC")
    fun getAllSavedPlanets(): Flow<List<PlanetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlanet(planet: PlanetEntity)

    @Delete
    suspend fun deletePlanet(planet: PlanetEntity)

    @Query("DELETE FROM saved_planets WHERE id = :id")
    suspend fun deletePlanetById(id: String)
}
