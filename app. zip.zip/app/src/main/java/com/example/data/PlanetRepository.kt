package com.example.data

import com.example.model.PlanetData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PlanetRepository(private val planetDao: PlanetDao) {
    val savedPlanets: Flow<List<PlanetData>> = planetDao.getAllSavedPlanets().map { entities ->
        entities.map { it.toPlanetData() }
    }

    suspend fun savePlanet(planet: PlanetData) {
        planetDao.insertPlanet(PlanetEntity.fromPlanetData(planet))
    }

    suspend fun deletePlanet(planetId: String) {
        planetDao.deletePlanetById(planetId)
    }
}
