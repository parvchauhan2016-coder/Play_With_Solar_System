package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.AtmosphereComposition
import com.example.model.PlanetData
import com.example.model.SurfaceComposition

@Entity(tableName = "saved_planets")
data class PlanetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val massEarth: Double,
    val radiusEarth: Double,
    val distanceFromStarAu: Double,
    val rotationPeriodHours: Double,
    val customYearDays: Double?,
    val axialTiltDegrees: Float,
    val overrideTempKelvin: Double?,
    val atmosphericPressureAtm: Double,
    val nitrogenPct: Float,
    val oxygenPct: Float,
    val carbonDioxidePct: Float,
    val methanePct: Float,
    val argonOtherPct: Float,
    val oceanPct: Float,
    val landPct: Float,
    val icePct: Float,
    val desertPct: Float,
    val forestPct: Float,
    val mountainPct: Float,
    val waterPct: Float,
    val cloudPct: Float,
    val magneticFieldStrengthGauss: Double,
    val moonCount: Int,
    val hasRings: Boolean,
    val ringColorHex: Long,
    val baseColorHex: Long,
    val landColorHex: Long
) {
    fun toPlanetData(): PlanetData {
        return PlanetData(
            id = id,
            name = name,
            isPreset = false,
            massEarth = massEarth,
            radiusEarth = radiusEarth,
            distanceFromStarAu = distanceFromStarAu,
            rotationPeriodHours = rotationPeriodHours,
            customYearDays = customYearDays,
            axialTiltDegrees = axialTiltDegrees,
            overrideTempKelvin = overrideTempKelvin,
            atmosphericPressureAtm = atmosphericPressureAtm,
            atmosphere = AtmosphereComposition(nitrogenPct, oxygenPct, carbonDioxidePct, methanePct, argonOtherPct),
            surface = SurfaceComposition(oceanPct, landPct, icePct, desertPct, forestPct, mountainPct),
            waterPct = waterPct,
            icePct = icePct,
            cloudPct = cloudPct,
            magneticFieldStrengthGauss = magneticFieldStrengthGauss,
            moonCount = moonCount,
            hasRings = hasRings,
            ringColorHex = ringColorHex,
            baseColorHex = baseColorHex,
            landColorHex = landColorHex
        )
    }

    companion object {
        fun fromPlanetData(data: PlanetData): PlanetEntity {
            return PlanetEntity(
                id = data.id,
                name = data.name,
                massEarth = data.massEarth,
                radiusEarth = data.radiusEarth,
                distanceFromStarAu = data.distanceFromStarAu,
                rotationPeriodHours = data.rotationPeriodHours,
                customYearDays = data.customYearDays,
                axialTiltDegrees = data.axialTiltDegrees,
                overrideTempKelvin = data.overrideTempKelvin,
                atmosphericPressureAtm = data.atmosphericPressureAtm,
                nitrogenPct = data.atmosphere.nitrogenPct,
                oxygenPct = data.atmosphere.oxygenPct,
                carbonDioxidePct = data.atmosphere.carbonDioxidePct,
                methanePct = data.atmosphere.methanePct,
                argonOtherPct = data.atmosphere.argonOtherPct,
                oceanPct = data.surface.oceanPct,
                landPct = data.surface.landPct,
                icePct = data.surface.icePct,
                desertPct = data.surface.desertPct,
                forestPct = data.surface.forestPct,
                mountainPct = data.surface.mountainPct,
                waterPct = data.waterPct,
                cloudPct = data.cloudPct,
                magneticFieldStrengthGauss = data.magneticFieldStrengthGauss,
                moonCount = data.moonCount,
                hasRings = data.hasRings,
                ringColorHex = data.ringColorHex,
                baseColorHex = data.baseColorHex,
                landColorHex = data.landColorHex
            )
        }
    }
}
