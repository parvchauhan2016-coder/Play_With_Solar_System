package com.example.model

import androidx.compose.ui.graphics.Color
import kotlin.math.pow
import kotlin.math.sqrt

enum class StarType(
    val displayName: String,
    val defaultMassSolar: Double,
    val defaultTempKelvin: Double,
    val defaultLuminositySolar: Double,
    val defaultRadiusSolar: Double,
    val starColorHex: Long
) {
    YELLOW_DWARF("G-Type (Sol-like)", 1.0, 5778.0, 1.0, 1.0, 0xFFFFF4EA),
    RED_DWARF("M-Type (Red Dwarf)", 0.3, 3200.0, 0.015, 0.4, 0xFFFF6B4A),
    BLUE_GIANT("O-Type (Blue Giant)", 15.0, 30000.0, 20000.0, 6.6, 0xFF88CCFF),
    WHITE_DWARF("White Dwarf", 0.6, 12000.0, 0.001, 0.012, 0xFFE0F7FA),
    RED_GIANT("Red Giant", 2.0, 3500.0, 500.0, 25.0, 0xFFFF4500)
}

data class StarData(
    val name: String = "Sol",
    val type: StarType = StarType.YELLOW_DWARF,
    val massSolar: Double = 1.0,           // M_sun
    val tempKelvin: Double = 5778.0,       // K
    val luminositySolar: Double = 1.0,     // L_sun
    val radiusSolar: Double = 1.0          // R_sun
)

data class AtmosphereComposition(
    val nitrogenPct: Float = 78.08f,
    val oxygenPct: Float = 20.95f,
    val carbonDioxidePct: Float = 0.04f,
    val methanePct: Float = 0.0002f,
    val argonOtherPct: Float = 0.93f
) {
    fun normalized(): AtmosphereComposition {
        val sum = nitrogenPct + oxygenPct + carbonDioxidePct + methanePct + argonOtherPct
        if (sum <= 0f) return AtmosphereComposition(100f, 0f, 0f, 0f, 0f)
        return AtmosphereComposition(
            nitrogenPct = (nitrogenPct / sum) * 100f,
            oxygenPct = (oxygenPct / sum) * 100f,
            carbonDioxidePct = (carbonDioxidePct / sum) * 100f,
            methanePct = (methanePct / sum) * 100f,
            argonOtherPct = (argonOtherPct / sum) * 100f
        )
    }
}

data class SurfaceComposition(
    val oceanPct: Float = 71f,
    val landPct: Float = 29f,
    val icePct: Float = 10f,
    val desertPct: Float = 15f,
    val forestPct: Float = 20f,
    val mountainPct: Float = 10f
)

data class CraterPoint(
    val xRatio: Float,
    val yRatio: Float,
    val radiusDp: Float
)

data class PlanetData(
    val id: String = "earth",
    val name: String = "Earth",
    val isPreset: Boolean = true,
    
    // Physical & Orbital Properties
    val massEarth: Double = 1.0,           // M_earth
    val radiusEarth: Double = 1.0,         // R_earth
    val distanceFromStarAu: Double = 1.0,  // AU
    val rotationPeriodHours: Double = 24.0,// Hours per day
    val customYearDays: Double? = null,    // If set manually, otherwise auto calculated
    val axialTiltDegrees: Float = 23.44f,  // Degrees
    val overrideTempKelvin: Double? = null,// If user overrides
    
    // Atmosphere & Surface
    val atmosphericPressureAtm: Double = 1.0, // atm
    val atmosphere: AtmosphereComposition = AtmosphereComposition(),
    val surface: SurfaceComposition = SurfaceComposition(),
    
    // Visual / Features
    val waterPct: Float = 71f,
    val icePct: Float = 10f,
    val cloudPct: Float = 50f,
    val magneticFieldStrengthGauss: Double = 0.5, // Earth ~ 0.5 Gauss
    val moonCount: Int = 1,
    val hasRings: Boolean = false,
    val ringColorHex: Long = 0xAAAEAA8C,
    val baseColorHex: Long = 0xFF2B82C5,
    val landColorHex: Long = 0xFF4A7C59,

    // Game & Interactive Sandbox Features
    val healthPct: Float = 100f,
    val shieldActive: Boolean = false,
    val shieldPowerPct: Float = 100f,
    val humanPopulation: Long = 8_000_000_000L,
    val impactCraters: List<CraterPoint> = emptyList(),
    val isGenerated: Boolean = true
) {
    // Physics calculations
    val surfaceGravityEarth: Double
        get() = massEarth / (radiusEarth * radiusEarth)

    val surfaceGravityMs2: Double
        get() = surfaceGravityEarth * 9.80665

    fun calculateOrbitalPeriodDays(starMassSolar: Double): Double {
        if (customYearDays != null && customYearDays > 0) return customYearDays
        // Kepler's Third Law: T^2 = a^3 / M_star (in years)
        val years = sqrt((distanceFromStarAu * distanceFromStarAu * distanceFromStarAu) / starMassSolar.coerceAtLeast(0.01))
        return years * 365.25
    }

    fun calculateEquilibriumTempKelvin(starLuminositySolar: Double): Double {
        // T_eq = 278.5 * (L_star)^0.25 / sqrt(a_AU)
        // Albedo estimate: higher ice/clouds = higher albedo
        val albedo = (icePct * 0.7f + cloudPct * 0.5f + waterPct * 0.06f + (100f - waterPct) * 0.2f) / 100f
        val effectiveAlbedo = albedo.coerceIn(0.05f, 0.85f)
        val tEq = 278.5 * (1.0 - effectiveAlbedo).pow(0.25) * starLuminositySolar.pow(0.25) / sqrt(distanceFromStarAu.coerceAtLeast(0.01))
        
        // Greenhouse Effect calculation based on atmospheric pressure & CO2/Methane
        val co2Factor = atmosphere.carbonDioxidePct / 100.0
        val ch4Factor = atmosphere.methanePct / 100.0
        val greenhouseDelta = (atmosphericPressureAtm.pow(0.35) * (co2Factor * 300.0 + ch4Factor * 500.0 + 33.0)).coerceIn(0.0, 500.0)
        
        val totalCalculated = tEq + greenhouseDelta
        return overrideTempKelvin ?: totalCalculated
    }

    fun calculateHabitabilityScore(star: StarData): HabitabilityReport {
        val tempK = calculateEquilibriumTempKelvin(star.luminositySolar)
        val tempCelsius = tempK - 273.15
        val gravityG = surfaceGravityEarth
        
        // Temperature score (Optimal: 0°C to 30°C)
        val tempScore = when {
            tempCelsius in 0.0..30.0 -> 100.0
            tempCelsius in -20.0..0.0 -> 100.0 + (tempCelsius * 3.5)
            tempCelsius in 30.0..60.0 -> 100.0 - ((tempCelsius - 30.0) * 3.0)
            tempCelsius < -50.0 || tempCelsius > 100.0 -> 0.0
            else -> 20.0
        }.coerceIn(0.0, 100.0)

        // Atmosphere score (Breathable oxygen ~15-25%, non-toxic pressure ~0.5 - 2 atm)
        val oxygenPct = atmosphere.oxygenPct
        val pressure = atmosphericPressureAtm
        val oxygenScore = if (oxygenPct in 15.0..25.0) 100.0 else (oxygenPct * 4.0).coerceIn(0.0, 100.0)
        val pressureScore = when {
            pressure in 0.5..2.5 -> 100.0
            pressure in 0.1..0.5 -> pressure * 200.0
            pressure in 2.5..10.0 -> 100.0 - (pressure - 2.5) * 12.0
            else -> 0.0
        }.coerceIn(0.0, 100.0)
        val atmosphereScore = (oxygenScore * 0.6 + pressureScore * 0.4)

        // Water score (Need liquid water)
        val liquidWaterPossible = tempCelsius in -10.0..100.0 && pressure > 0.006
        val waterScore = if (liquidWaterPossible) waterPct.toDouble().coerceIn(0.0, 100.0) else 0.0

        // Magnetic protection score
        val magneticScore = (magneticFieldStrengthGauss / 0.5 * 100.0).coerceIn(0.0, 100.0)

        // Gravity comfort
        val gravityScore = when {
            gravityG in 0.6..1.5 -> 100.0
            gravityG in 0.1..0.6 -> gravityG * 160.0
            gravityG in 1.5..4.0 -> 100.0 - (gravityG - 1.5) * 30.0
            else -> 0.0
        }.coerceIn(0.0, 100.0)

        val totalScore = (tempScore * 0.30 + atmosphereScore * 0.25 + waterScore * 0.25 + magneticScore * 0.10 + gravityScore * 0.10).coerceIn(0.0, 100.0)

        val status = when {
            totalScore >= 80 -> "Optimal Earth-like Habitable Zone"
            totalScore >= 50 -> "Marginally Habitable / Extremophile Zone"
            totalScore >= 25 -> "Hostile Environment (Requires Life Support)"
            else -> "Barren & Uninhabitable Wasteland"
        }

        return HabitabilityReport(
            overallScorePct = totalScore.toInt(),
            statusText = status,
            tempScore = tempScore.toInt(),
            atmosphereScore = atmosphereScore.toInt(),
            waterScore = waterScore.toInt(),
            magneticScore = magneticScore.toInt(),
            gravityScore = gravityScore.toInt(),
            liquidWaterPossible = liquidWaterPossible
        )
    }

    companion object {
        // Presets & Solar System Default Planets
        val EARTH = PlanetData(
            id = "earth",
            name = "Earth",
            isPreset = true,
            massEarth = 1.0,
            radiusEarth = 1.0,
            distanceFromStarAu = 1.0,
            rotationPeriodHours = 24.0,
            axialTiltDegrees = 23.44f,
            atmosphericPressureAtm = 1.0,
            atmosphere = AtmosphereComposition(78.08f, 20.95f, 0.04f, 0.0002f, 0.93f),
            surface = SurfaceComposition(71f, 29f, 10f, 15f, 25f, 10f),
            waterPct = 71f,
            icePct = 10f,
            cloudPct = 50f,
            magneticFieldStrengthGauss = 0.5,
            moonCount = 1,
            hasRings = false,
            baseColorHex = 0xFF1D5290,
            landColorHex = 0xFF3D7243
        )

        val MARS = PlanetData(
            id = "mars",
            name = "Mars",
            isPreset = true,
            massEarth = 0.107,
            radiusEarth = 0.532,
            distanceFromStarAu = 1.524,
            rotationPeriodHours = 24.6,
            axialTiltDegrees = 25.19f,
            atmosphericPressureAtm = 0.006,
            atmosphere = AtmosphereComposition(2.6f, 0.13f, 95.32f, 0.0001f, 1.95f),
            surface = SurfaceComposition(0f, 100f, 15f, 75f, 0f, 25f),
            waterPct = 0f,
            icePct = 15f,
            cloudPct = 10f,
            magneticFieldStrengthGauss = 0.001,
            moonCount = 2,
            hasRings = false,
            baseColorHex = 0xFFC85232,
            landColorHex = 0xFF993A1D
        )

        val VENUS = PlanetData(
            id = "venus",
            name = "Venus",
            isPreset = true,
            massEarth = 0.815,
            radiusEarth = 0.949,
            distanceFromStarAu = 0.723,
            rotationPeriodHours = 5832.5, // 243 earth days
            axialTiltDegrees = 177.3f,
            atmosphericPressureAtm = 92.0,
            atmosphere = AtmosphereComposition(3.5f, 0.0f, 96.5f, 0.0f, 0.0f),
            surface = SurfaceComposition(0f, 100f, 0f, 90f, 0f, 30f),
            waterPct = 0f,
            icePct = 0f,
            cloudPct = 95f,
            magneticFieldStrengthGauss = 0.00001,
            moonCount = 0,
            hasRings = false,
            baseColorHex = 0xFFE3A857,
            landColorHex = 0xFFB87832
        )

        val MERCURY = PlanetData(
            id = "mercury",
            name = "Mercury",
            isPreset = true,
            massEarth = 0.055,
            radiusEarth = 0.383,
            distanceFromStarAu = 0.387,
            rotationPeriodHours = 1407.6,
            axialTiltDegrees = 0.03f,
            atmosphericPressureAtm = 0.000001,
            atmosphere = AtmosphereComposition(0f, 42f, 0f, 0f, 58f),
            surface = SurfaceComposition(0f, 100f, 2f, 80f, 0f, 35f),
            waterPct = 0f,
            icePct = 2f,
            cloudPct = 0f,
            magneticFieldStrengthGauss = 0.003,
            moonCount = 0,
            hasRings = false,
            baseColorHex = 0xFF8C8C8C,
            landColorHex = 0xFF595959
        )

        val JUPITER = PlanetData(
            id = "jupiter",
            name = "Jupiter",
            isPreset = true,
            massEarth = 317.8,
            radiusEarth = 11.21,
            distanceFromStarAu = 5.204,
            rotationPeriodHours = 9.93,
            axialTiltDegrees = 3.13f,
            atmosphericPressureAtm = 100.0,
            atmosphere = AtmosphereComposition(0f, 0f, 0f, 0.3f, 99.7f),
            surface = SurfaceComposition(0f, 0f, 0f, 0f, 0f, 0f),
            waterPct = 0f,
            icePct = 0f,
            cloudPct = 100f,
            magneticFieldStrengthGauss = 4.2,
            moonCount = 95,
            hasRings = true,
            ringColorHex = 0x55C8B496,
            baseColorHex = 0xFFC89664,
            landColorHex = 0xFF966432
        )

        val SATURN = PlanetData(
            id = "saturn",
            name = "Saturn",
            isPreset = true,
            massEarth = 95.2,
            radiusEarth = 9.45,
            distanceFromStarAu = 9.58,
            rotationPeriodHours = 10.7,
            axialTiltDegrees = 26.73f,
            atmosphericPressureAtm = 100.0,
            atmosphere = AtmosphereComposition(0f, 0f, 0f, 0.4f, 99.6f),
            surface = SurfaceComposition(0f, 0f, 0f, 0f, 0f, 0f),
            waterPct = 0f,
            icePct = 0f,
            cloudPct = 100f,
            magneticFieldStrengthGauss = 0.2,
            moonCount = 146,
            hasRings = true,
            ringColorHex = 0xCCD4C29A,
            baseColorHex = 0xFFE6CF9B,
            landColorHex = 0xFFB39F6E
        )

        val URANUS = PlanetData(
            id = "uranus",
            name = "Uranus",
            isPreset = true,
            massEarth = 14.5,
            radiusEarth = 4.01,
            distanceFromStarAu = 19.22,
            rotationPeriodHours = 17.2,
            axialTiltDegrees = 97.77f,
            atmosphericPressureAtm = 100.0,
            atmosphere = AtmosphereComposition(0f, 0f, 0f, 2.3f, 97.7f),
            surface = SurfaceComposition(0f, 0f, 0f, 0f, 0f, 0f),
            waterPct = 0f,
            icePct = 80f,
            cloudPct = 90f,
            magneticFieldStrengthGauss = 0.23,
            moonCount = 28,
            hasRings = true,
            ringColorHex = 0x887AC5CD,
            baseColorHex = 0xFF6DB1B3,
            landColorHex = 0xFF4A888A
        )

        val NEPTUNE = PlanetData(
            id = "neptune",
            name = "Neptune",
            isPreset = true,
            massEarth = 17.1,
            radiusEarth = 3.88,
            distanceFromStarAu = 30.05,
            rotationPeriodHours = 16.1,
            axialTiltDegrees = 28.32f,
            atmosphericPressureAtm = 100.0,
            atmosphere = AtmosphereComposition(0f, 0f, 0f, 1.5f, 98.5f),
            surface = SurfaceComposition(0f, 0f, 0f, 0f, 0f, 0f),
            waterPct = 0f,
            icePct = 85f,
            cloudPct = 80f,
            magneticFieldStrengthGauss = 0.14,
            moonCount = 16,
            hasRings = true,
            ringColorHex = 0x884682B4,
            baseColorHex = 0xFF2B53A7,
            landColorHex = 0xFF1B3878
        )

        val MOON = PlanetData(
            id = "moon",
            name = "Moon",
            isPreset = true,
            massEarth = 0.0123,
            radiusEarth = 0.273,
            distanceFromStarAu = 1.0,
            rotationPeriodHours = 708.7,
            axialTiltDegrees = 6.68f,
            atmosphericPressureAtm = 0.00000001,
            atmosphere = AtmosphereComposition(0f, 0f, 0f, 0f, 100f),
            surface = SurfaceComposition(0f, 100f, 0f, 60f, 0f, 40f),
            waterPct = 0f,
            icePct = 1f,
            cloudPct = 0f,
            magneticFieldStrengthGauss = 0.0,
            moonCount = 0,
            hasRings = false,
            baseColorHex = 0xFFA0A0A0,
            landColorHex = 0xFF666666
        )

        // Speculative Presets
        val SUPER_EARTH = PlanetData(
            id = "super_earth",
            name = "Super-Earth",
            isPreset = true,
            massEarth = 4.5,
            radiusEarth = 1.6,
            distanceFromStarAu = 1.15,
            rotationPeriodHours = 18.0,
            axialTiltDegrees = 15.0f,
            atmosphericPressureAtm = 2.2,
            atmosphere = AtmosphereComposition(70f, 25f, 1f, 0.1f, 3.9f),
            surface = SurfaceComposition(65f, 35f, 12f, 10f, 40f, 20f),
            waterPct = 65f,
            icePct = 12f,
            cloudPct = 60f,
            magneticFieldStrengthGauss = 1.2,
            moonCount = 2,
            hasRings = false,
            baseColorHex = 0xFF2874A6,
            landColorHex = 0xFF1E8449
        )

        val DESERT_WORLD = PlanetData(
            id = "desert_world",
            name = "Desert World",
            isPreset = true,
            massEarth = 0.9,
            radiusEarth = 0.95,
            distanceFromStarAu = 0.9,
            rotationPeriodHours = 28.0,
            axialTiltDegrees = 12.0f,
            atmosphericPressureAtm = 0.8,
            atmosphere = AtmosphereComposition(85f, 12f, 2f, 0.0f, 1f),
            surface = SurfaceComposition(5f, 95f, 0f, 85f, 5f, 10f),
            waterPct = 5f,
            icePct = 0f,
            cloudPct = 15f,
            magneticFieldStrengthGauss = 0.4,
            moonCount = 1,
            hasRings = false,
            baseColorHex = 0xFFD4AC0D,
            landColorHex = 0xFFB9770E
        )

        val ICE_WORLD = PlanetData(
            id = "ice_world",
            name = "Ice World",
            isPreset = true,
            massEarth = 1.2,
            radiusEarth = 1.1,
            distanceFromStarAu = 2.8,
            rotationPeriodHours = 32.0,
            axialTiltDegrees = 30.0f,
            atmosphericPressureAtm = 0.5,
            atmosphere = AtmosphereComposition(90f, 5f, 4f, 0.5f, 0.5f),
            surface = SurfaceComposition(0f, 100f, 90f, 0f, 0f, 10f),
            waterPct = 0f,
            icePct = 90f,
            cloudPct = 40f,
            magneticFieldStrengthGauss = 0.6,
            moonCount = 3,
            hasRings = false,
            baseColorHex = 0xFFA9CCE3,
            landColorHex = 0xFF5499C7
        )

        val OCEAN_WORLD = PlanetData(
            id = "ocean_world",
            name = "Ocean World",
            isPreset = true,
            massEarth = 2.0,
            radiusEarth = 1.3,
            distanceFromStarAu = 1.05,
            rotationPeriodHours = 22.0,
            axialTiltDegrees = 8.0f,
            atmosphericPressureAtm = 1.8,
            atmosphere = AtmosphereComposition(75f, 22f, 1.5f, 0.1f, 1.4f),
            surface = SurfaceComposition(100f, 0f, 5f, 0f, 0f, 0f),
            waterPct = 100f,
            icePct = 5f,
            cloudPct = 75f,
            magneticFieldStrengthGauss = 0.8,
            moonCount = 1,
            hasRings = true,
            ringColorHex = 0x664682B4,
            baseColorHex = 0xFF1F618D,
            landColorHex = 0xFF154360
        )

        val HIGH_GRAVITY_WORLD = PlanetData(
            id = "high_gravity",
            name = "High-Gravity World",
            isPreset = true,
            massEarth = 8.0,
            radiusEarth = 1.4,
            distanceFromStarAu = 1.2,
            rotationPeriodHours = 14.0,
            axialTiltDegrees = 5.0f,
            atmosphericPressureAtm = 5.0,
            atmosphere = AtmosphereComposition(80f, 10f, 8f, 0.5f, 1.5f),
            surface = SurfaceComposition(50f, 50f, 10f, 20f, 30f, 40f),
            waterPct = 50f,
            icePct = 10f,
            cloudPct = 80f,
            magneticFieldStrengthGauss = 2.5,
            moonCount = 4,
            hasRings = false,
            baseColorHex = 0xFF6C3483,
            landColorHex = 0xFF512E5F
        )

        val ALL_PRESETS = listOf(
            EARTH, MARS, VENUS, MERCURY, JUPITER, SATURN, URANUS, NEPTUNE, MOON,
            SUPER_EARTH, DESERT_WORLD, ICE_WORLD, OCEAN_WORLD, HIGH_GRAVITY_WORLD
        )
    }
}

data class HabitabilityReport(
    val overallScorePct: Int,
    val statusText: String,
    val tempScore: Int,
    val atmosphereScore: Int,
    val waterScore: Int,
    val magneticScore: Int,
    val gravityScore: Int,
    val liquidWaterPossible: Boolean
)
